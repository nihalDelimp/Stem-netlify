import React, { useEffect, useState } from 'react'
import { Button, Card, Container, Modal, Row } from 'react-bootstrap'
import { useDispatch } from 'react-redux'
import { getProductList } from '../../Redux/action/Product'
import IsLoadingHOC from '../../Components/IsLoadingHOC'
import { IsloggedinHOC } from '../../Components/IsLoggedinHOC'
import { useSelector } from 'react-redux'
import DummyModal from '../../Components/Modal'
import '../../assets/css/component/product.css'
const Product = (props) => {
    const { setLoading } = props;
    const dispatch = useDispatch();
    const product_data = useSelector(state => state.product.product_list);
    const [productId, setProductId] = useState("");
    const [productItem, setProductItem] = useState({});
    const [productData, setProductData] = useState([]);
    const [isClicked, setIsClicked] = useState(false);

    const [show, setShow] = useState(false);
    const [product_name, set_product_name] = useState("");
    const getProductListData = async () => {
        // setLoading(true);
        await dispatch(getProductList())
            .then(
                response => {
                    console.log(response.data, "niahsihsda")
                    setProductData(response.data)
                    // setLoading(false);
                },
                () => {
                    console.log(false);
                    // setLoading(false);
                }
            )
            .catch(
                error => console.log(error)
            )
    }
    useEffect(async () => {
        await dispatch(getProductListData())
    }, []);

    const handleClose = () => setShow(false);
    const handleModal = (item) => {
        setProductItem(item)
        setProductId(item.id)
        setShow(true)
        set_product_name(item.title)
        setIsClicked(true)
    }
    return (
        <>
            {isClicked === true ? <DummyModal product_details={productItem} show={show} handleClose={handleClose} /> : null}
            {/* <Modal show={show}>
                <Modal.Header closeButton onClick={handleClose}>
                    <Modal.Title>{product_name}</Modal.Title>
                </Modal.Header>
                <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
            </Modal> */}
            <Container>
                <br />
                <br />
                {productData.map((item, index) => (
                    <Row>
                        <Card key={index} onClick={() => handleModal(item)} style={{ width: '14rem' }} >
                            <Card.Img variant="top" src={item.images[0].src} />
                            <Card.Body>
                                <Card.Title>{item.title}</Card.Title>
                            </Card.Body>
                        </Card>
                    </Row>
                )
                )}
            </Container>
        </>
    )
}

export default Product;