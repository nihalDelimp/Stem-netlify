import React from 'react'
import { Link } from 'react-router-dom';
import '../../assets/css/component/product.css'
const FooterProduct = () => {
    return (
        <div class="submit--product--section">
            <div class="submit--product">
                <div class="product--item--header">
                    <div class="product--item--inner">
                        <div class="view--product">
                            <div class="view-product--wrapper">
                                <h3>View</h3>
                                <img src="../../assets/img/down.png" alt="" />
                            </div>
                        </div>
                        <div class="added--product">
                            <div class="added-product--wrapper">
                                <h3>Added Items</h3>
                                <h5>0</h5>
                            </div>
                        </div>
                        <div class="value--product">
                            <div class="value-product--wrapper">
                                <h3>Value</h3>
                                <h5><span>$</span>0</h5>
                            </div>
                        </div>
                        <div class="submit--product">
                            <div class="submit-product--wrapper">
                                <Link to="/seller/ticket">
                                    <button type="button" >Submit Items</button>
                                </Link>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="product--item--data">
                    <div class="product--item--data-item">
                        <div class="pre--aproved">
                            <div class="pre--aproved--text">
                                <img src="img/approved.png" alt="" />
                                <h4>Pre-approved</h4>
                            </div>
                        </div>
                        <div class="pre-approved-data">
                            <div class="pre-ap-data">
                                <span>The following items have been pre-approved and are ready to be inspected.</span>
                                <img src="img/qustion.png" alt="" />
                            </div>
                        </div>
                        <div class="products--items">
                            <div class="products--item--inner">
                                <div class="product--item">
                                    <span class="badge">4</span>
                                    <img src="img/shose.png" alt="" />
                                    <h3>Air Jordan 1</h3>
                                    <h5><span>555088 063</span> | 3.5</h5>
                                </div>
                                <div class="product--item">
                                    <span class="badge">4</span>
                                    <img src="img/shose.png" alt="" />
                                    <h3>Air Jordan 1</h3>
                                    <h5><span>555088 063</span> | 3.5</h5>
                                </div>
                                <div class="product--item">
                                    <span class="badge">4</span>
                                    <img src="img/shose.png" alt="" />
                                    <h3>Air Jordan 1</h3>
                                    <h5><span>555088 063</span> | 3.5</h5>
                                </div>
                                <div class="product--item">
                                    <span class="badge">4</span>
                                    <img src="img/shose.png" alt="" />
                                    <h3>Air Jordan 1</h3>
                                    <h5><span>555088 063</span> | 3.5</h5>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="product--item--data-item">
                        <div class="pre--aproved">
                            <div class="pre--aproved--text">
                                <img src="img/under-reviw.png" alt="" />
                                <h4>UNDER REVIEW</h4>
                            </div>
                        </div>
                        <div class="pre-approved-data">
                            <div class="pre-ap-data">
                                <span>The following items have not been pre-approved. Edit items to qualify for pre-approval.</span>
                                <img src="img/qustion.png" alt="" />
                            </div>
                        </div>
                        <div class="no--product--yet">
                            <span>No products yet</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default FooterProduct;