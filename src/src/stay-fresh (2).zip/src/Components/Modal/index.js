import React, { useEffect, useState } from 'react'
import { Modal, Button } from 'react-bootstrap';
import FooterProduct from '../FooterProduct';
const DummyModal = (props) => {
    const [showNote, setshowNote] = useState(false)
    const [showFooter, setShowFooter] = useState(false)
    const [item, setItem] = useState()
    {
        props.product_details.options.some((o) => {
            o["name"] === "Size" ?
                o.values.map((item, index) => (
                    console.log(item)
                )
                ) : (<p>"nihal"</p>)
        }
        )
    }
    const handleCart = () => {
        setshowNote(true)
    }

    const handleFooter = () => {
        setShowFooter(true)
    }
    return (
        <>
            <div id="myModal" className="modal fade show" style={{ display: props.show === true ? "block" : "none", paddingRight: "15px" }} aria-modal="true" role="dialog">
                <div className="modal-dialog modal-lg">
                    <div className="modal-content">
                        <div className="modal-header">
                            <button type="button" className="btn" onClick={props.handleClose} data-dismiss="modal">&times;</button>
                        </div>
                        <div className="modal-body" id="product_id">
                            <div className="container-fluid">
                                <div className="row">
                                    <div className="col-md-3 product_image">
                                        <img src={props.product_details.image.src} className="img-fluid" />
                                    </div>
                                    <div className="col-md-9">
                                        <h4 className="product_name"></h4>
                                        <ul className="list-inline">
                                            <li className="list-inline-item">SKU CW2288 111</li>
                                            <li className="list-inline-item">WHITE/WHITE</li>
                                        </ul>
                                        <div>
                                            <ul className="list-inline">
                                                <li className="list-inline-item">MENS</li>
                                                <li className="list-inline-item">2020</li>
                                                <li className="list-inline-item">WHITE ON WHITE</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <hr />
                                <p><b>SELECT SIZES</b></p>
                                <div className="row" >
                                    <div className="col-md-3 col-sm-3 col-xs-3">
                                        <button type="button" className="btn btn-block btn-outline-secondary mb-2" onClick={handleCart}>5</button>
                                    </div>
                                </div>

                                {props.product_details.options.some((o) => (
                                    o["name"] === "Size" &&
                                    o.values.map((item, index) => (
                                        < div className="row" key={index} >
                                            <div className="col-md-3 col-sm-3 col-xs-3">
                                                <button type="button" className="btn btn-block btn-outline-secondary mb-2">{item}</button>
                                            </div>
                                        </div>
                                    )
                                    )
                                ))}
                                <hr />
                                <div className="product_note" style={{ display: showNote ? "block" : "none" }}>
                                    <p><b>ADD DETAILS</b></p>
                                    <p>Input the quantity and condition of your item(s) and then set a price. Our suggested price is based on
                                        recent sales. Stay within the pre-approved range to list your item(s) immediately.
                                        Please note, anything marked “Special Box” should only refer to rare or limited edition packaging.
                                        Anything marked “Sample” should only refer to a sample directly from the factory.</p>
                                    <p>Please note, anything marked “Special Box” should only refer to rare or limited edition packaging.
                                        Anything marked “Sample” should only refer to a sample directly from the factory.</p>
                                    <hr />
                                </div>
                                <div id="product_list">
                                </div>
                                <a className="btn btn-danger btn-lg mb-2 add_products" href="#" id="add_products" role="button" onClick={handleFooter}>Add products</a>
                            </div>
                            <div className="modal-footer">
                                <button type="button" className="btn btn-default" data-dismiss="modal" onClick={props.handleClose}>Close</button>
                            </div>
                        </div>
                    </div>

                </div>
                {showNote ? <FooterProduct /> : ""}

            </div>
            {/* <Modal show={props.show}>
                <Modal.Header closeButton>
                    <Modal.Title>Modal heading</Modal.Title>
                </Modal.Header>
                <Modal.Body>Woohoo, you're reading this text in a modal!</Modal.Body>
                <Modal.Footer>
                </Modal.Footer>
            </Modal> */}

        </>
    );
}

export default DummyModal