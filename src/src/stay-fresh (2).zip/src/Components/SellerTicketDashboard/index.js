import React from 'react'
import './sellerticket.css'
const SellerTicket = () => {
    return (
        <>
            <section className="ticket--status">
                <div className="ticket--status--wrapper">
                    <div className="ticket--number-wrapper">
                        <div className="ticket--number">
                            <span>TICKET</span>
                            <span>#14675878</span>
                        </div>
                        <div className="ticket--status-data">
                            <div><span>Ticket Status</span></div>
                            <div><span>APPROVED</span></div>
                            <div><span>Created</span></div>
                            <div><span>02/25/2022</span></div>
                            <div><span>Submitted</span></div>
                            <div><span>03/01/2022</span></div>
                        </div>
                    </div>
                    <div className="qr--code">
                        <img src="img/qr--code.jpg" alt="" />
                    </div>
                </div>
            </section>
            <section className="items--shipment">
                <div className="items--shipment--wrapper">
                    <div className="shipment--tab--header">
                        <div className="tab--list">
                            <ul>
                                <li className="active--list">Items</li>
                                <li>Shipments <span>(0)</span></li>
                            </ul>
                        </div>
                        <tab className="list--status">
                            <div className="tab--list--group">
                                <div><span>PENDING</span> <span>0</span></div>
                                <div><span>MODIFIED</span> <span>0</span></div>
                                <div><span>APPROVED</span> <span>1</span></div>
                                <div><span>REJECTED</span> <span>0</span></div>
                                <div><span>EXPIRED</span> <span>0</span></div>
                            </div>
                        </tab>
                    </div>
                    <div className="tab--content-shipment">
                        <div className="tab--data1 tab--content-main active--tab">
                            <div className="pre--aproved">
                                <div className="pre--aproved--text">
                                    <img src="img/approved.png" alt="" />
                                    <h4>approved</h4>
                                </div>
                            </div>
                            <p>The following items have been pre-approved and are ready to be inspected. Ship these items to our warehouse or drop them off at a retail
                                location within 14 days of approval. After 14 days, this ticket will expire and you will be required to submit a new ticket for pricing approval.
                            </p>
                            <div className="tab--btn--inner">
                                <button type="button" className="btn--tab">Ship Items</button>
                                <button type="button" className="btn--tab">Drop off</button>
                            </div>
                            <div className="product--details--tab">
                                <div className="img-product">
                                    <img src="img/shose.png" alt="" />
                                    <span>1</span>
                                </div>
                                <div className="modal--name">
                                    <h3>MODEL</h3>
                                    <span>Air Force 1 Low '07</span>
                                </div>
                                <div className="modal--SKU">
                                    <h3>SKU</h3>
                                    <span>CW2288 111</span>
                                </div>
                                <div className="modal--name">
                                    <h3>SIZE</h3>
                                    <span>8</span>
                                </div>
                                <div className="modal--PRICE">
                                    <h3>PRICE</h3>
                                    <span>$100</span>
                                </div>
                                <div className="modal--CONDITION">
                                    <h3>CONDITION</h3>
                                    <span>No Flaws</span>
                                </div>
                            </div>
                        </div>
                        <div className="tab--data1 tab--content-main">

                            <p>Ship approved items to our warehouse to be inspected. Select the type of box and items you want to include within to print a shipping label. Place the packing slip with your items inside the box and attach the shipping label to the outside.
                            </p>
                            <div className="tab--btn--inner">
                                <button type="button" className="btn--tab">Ship Items</button>
                                <button type="button" className="btn--tab">Drop off</button>
                            </div>
                            <p>Or schedule a drop off at our New York or Chicago market center.
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        </>
    )
}

export default SellerTicket