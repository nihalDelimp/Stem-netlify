import { Route, Switch } from 'react-router-dom';
import AppRoute from './AppRoute';
import Authorization from './Authorization';
import PrivateRoute from './PrivateRoute';
import PrivateLayout from '../Layout/Private';
import PublicLayout from '../Layout/Public';
import Login from '../Components/Login/Login';
import Home from '../Components/Home/Home';
import SellerTicketDashboard from '../Components/SellerTicketDashboard';
const Routing = () => {
    return (
        <Switch>
            <AppRoute
                exact
                path="/login"
                component={Login}
                layout={PublicLayout} />
            <PrivateRoute
                exact
                path="/"
                component={Home}
                layout={PrivateLayout} />
            <PrivateRoute
                exact
                path="/seller/ticket"
                component={SellerTicketDashboard}
                layout={PrivateLayout} />
            <Route
                path="*"
                component={() => (
                    <div style={{
                        display: "flex",
                        justifyContent: "center",
                        alignItems: "center",
                        height: "100vh"
                    }}>
                        <h1 style={{ color: "#000", fontSize: "2rem" }}>Page Not Found!!</h1>
                    </div>
                )}
            />
        </Switch>
    )
}
export default Routing;
