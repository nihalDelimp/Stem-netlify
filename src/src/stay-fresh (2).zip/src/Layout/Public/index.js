

// import bg from "../../assets/images/bg.png"
// import bg from "../../assets/images/bg2.jpg"

const PublicLayout = ({ children }) => {

    return (
        <div className="layout--public" >{children}</div>
    )
}

export default PublicLayout