import { withoutAuthAxios, authAxios } from "../../Config/axios"


export const getProductList = data => async _dispatch => {
    return new Promise(async (resolve, reject) => {
        await authAxios().post("/auth/seller/list-all-products", data)
            .then(
                response => {
                    resolve(response.data)
                    _dispatch({ type: "PRODUCT_DATA", payload: response.data.data });
                },
                error => {
                    reject(error)
                }
            )
            .catch(
                error => {
                    console.log(error);
                }
            )
    })
}